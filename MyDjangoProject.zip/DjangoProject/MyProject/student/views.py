from django.shortcuts import render
from student.models import Country, City, Student, Company
import csv
from django.http import HttpResponse
from django.http import FileResponse
import io
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter

def venue_pdf(request):
    # Create Bytestream buffer
    buf = io.BytesIO()
    # Create a Canvas
    c = canvas.Canvas(buf, pagesize=letter, bottomup=0)
    # Create a text object
    textob = c.beginText()
    textob.setTextOrigin(inch, inch)
    textob.setFont("Helvetica", 14)

    # Add some lines of text
    venues = Student.objects.all()
    lines = []
    for venue in venues:
        lines.append("==========================")
        lines.append(venue.student_name)
        lines.append(venue.address)
        lines.append(venue.branch)
        lines.append(venue.education)
        lines.append("==========================")

    max_lines_per_page = 30  # Adjust this based on the number of lines that fit on a page

    for i, line in enumerate(lines):
        if i > 0 and i % max_lines_per_page == 0:
            # Start a new page
            c.drawText(textob)
            c.showPage()
            textob = c.beginText()
            textob.setTextOrigin(inch, inch)
            textob.setFont("Helvetica", 14)

        textob.textLine(line)

    # Draw any remaining content on the last page
    c.drawText(textob)
    c.showPage()

    # Save the PDF to the buffer
    c.save()
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="venue_report.pdf"'
    response.write(buf.getvalue())
    buf.close()

    return response

def venue_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition']='attachment; filename=venues.csv'
    # Create a Csv writer
    writer = csv.writer(response)

    venues=Student.objects.all()
    writer.writerow(['Name','Address','Branch','Education'])

    for venue in venues:
        writer.writerow([venue.student_name,venue.address,venue.branch,venue.education])
    return response
def view_django(request):

    return render(request,'django.html',{})



def view_hello(request):

    return render(request,'hello.html',{})




def view_about(request):   

    return render(request,'about.html',{})



def view_record(request):

    stud_record = Student.objects.all()
    city_record = City.objects.all()

    # return render(request,'record.html',{'stud12':stud_record})
    return render(request,'record.html',{'stud12':stud_record,'city12':city_record})


       # return render_to_response('courtcase/report_display.html', {'entry_list': q, 'entry_list1': q1,})


    # return render_to_response('hello.html', {'entry_list': q, 'entry_list1': q1,})





# def index(request):
#     latest_question_list = Question.objects.order_by('-pub_date')[:5]
#     context = {'latest_question_list': latest_question_list}
#     return render(request, 'polls/index.html', context)
# Note that once we’ve done this in all these views, we no longer need to import loader and Ht




# Create your views here.

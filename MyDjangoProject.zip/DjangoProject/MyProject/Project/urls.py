from django.contrib import admin
from django.urls import include, re_path

from django.urls import include, re_path
from django.urls import path

from student.views import view_hello,view_record,view_about,venue_pdf,venue_csv
#from django.conf.urls import url

#from django.urls import include, re_path
#from myapp.views import home


urlpatterns = [
    re_path('admin/', admin.site.urls),
    re_path(r'^hello1/', view_hello, name='home'),
    re_path(r'^about/', view_about),
    re_path(r'^record1/', view_record),
    path('venue_pdf',venue_pdf,name='venue_pdf'),
    path('venue_csv',venue_csv,name='venue_csv')
]



